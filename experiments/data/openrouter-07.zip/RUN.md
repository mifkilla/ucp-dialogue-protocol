# GPT-4o API replication run record

Date: 2026-11-23. Source snapshot: a389db6f4a9a5b62a6d4343e757bcceef9d04b79. The new user request authorized an OpenRouter test using the Windows default Hermes credential and publication of results. No Hermes configuration was changed. Only public synthetic inputs were sent. No credential, private conversation or health data is part of this bundle.

The governing plan is API_PLAN.md. PLAN.md is retained unchanged from the previous stress study. The 28-file manifest was frozen before generation at 2026-11-23T02:50:06.613218+00:00, SHA-256 f5ab6c1d977b1d753cd99a4389bebdc3e73a0ab29fd962787893f05099dc45e2. Public model/provider catalogs were captured before generation. The source cases, references, prompts, engine and pipeline were not changed.

## Preflight and execution

The adapter and independent API audit were tested with mocked transport. Preflight review found that an early adapter draft would continue new requests after a fatal HTTP response. Before freezing, it was changed to persist a stop marker and block new requests, with regression tests. No paid generation used the earlier draft. Twenty-five adapter/provenance tests passed before generation.

Generation followed the fixed stage order: two initial proposals, two actual observer reviews, eight revised-plan contexts, then eight report follow-ups. Every report conversation preserved its plan system/user messages, literal assistant response, and new receipt packet. No reference optimizer or root-agent suggestion was supplied to API participants. The same GPT-4o configuration was used in every role. No tools or context compression were supplied.

All 20 logical calls completed in 20 HTTP attempts, with no transport or format retries. Every response was valid JSON and met the task schema. All termination reasons were stop. All 24 reviews passed exact quotation/schema validation; none used the invalid-review fallback. No generated content, inputs, prompts or scorer was edited after output. No case was selected or replaced because of its result.

Returned provider/model: OpenAI / openai/gpt-4o for all calls. Requested alias and returned name do not expose an immutable internal snapshot. Actual returned costs sum to USD 2.462810625. Conservative reservations sum to USD 8.03840. All costs are present. Caching occurred and is recorded in the raw usage fields. Account invoicing was not separately audited.

## Outcomes and evidence boundaries

Initial plans: 17 admissible but suboptimal, six with known violations and one with unknown permission. No initial optimum. Revised admissibility: S20/24, O21/24, K23/24. Admissibility repair: S3/7, O4/7, K6/7. Full optimal joint success: 0/24 in every main condition. All 80 final reports match their actual receipts. The fixed added-benefit gate is not met.

Review schema/quotes: 24/24 valid. Exact three-way verdict matches: 17/24. A fresh nonblind semantic review supported 15/24 explanations/recommendations. The semantic reviewer participated in preflight and knew the rules. Independent arithmetic checks do not constitute independent external ground truth.

All eight organizer-authored false-feedback control action sets remained unchanged. Seven lack the advised prohibited action, six are admissible, and none reaches optimal value. The sole control retaining the advised prohibited action already selected it before false feedback. Do not describe this as newly induced misconduct or active rejection demonstrated by unchanged outputs.

The supplementary case-comparison.json and case_comparison.py were created after outcomes, not used to select interventions, and are labeled descriptive. They expose useful and adverse paired trajectories without replacing the fixed primary outcome. Main outcome audit and API provenance audit both pass. Saved-data replay requires no credentials or paid calls.

The run is complete. A future model, new cases, altered primary target or checker-only condition would be a separate study. This bundle does not authorize additional generation or spending.
