"""Post-output descriptive comparison, not a new primary outcome or causal audit."""
from pathlib import Path
import hashlib
import json
import sys

BASE=Path(__file__).resolve().parent
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else (BASE if (BASE/'cases.json').exists() else BASE/'run-01')
sys.path.insert(0,str(ROOT))
import engine

def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
def short(case,plan):
    checked=engine.check_plan(case,plan)
    return {'selected':sorted(checked['selected']),'admissible':checked['admissible'],
            'verdict':checked['verdict'],'proposed_value':checked['selected_value'],
            'executed_value':checked['selected_value'] if checked['admissible'] else 0,
            'costs':checked['selected_cost'],
            'remaining_before':checked['current']['remaining'],
            'resource_margin':{k:checked['current']['remaining'][k]-checked['selected_cost'][k]
                               for k in engine.RESOURCES},
            'fault_types':[x['kind'] for x in checked['issues']],
            'issues':checked['issues']}
def relative(value,original):
    value['changed_action_set']=value['selected']!=original['selected']
    value['added_actions']=sorted(set(value['selected'])-set(original['selected']))
    value['removed_actions']=sorted(set(original['selected'])-set(value['selected']))
    value['admissibility_repair']=not original['admissible'] and value['admissible']
    value['admissibility_regression']=original['admissible'] and not value['admissible']
    value['executed_value_delta']=value['executed_value']-original['executed_value']
    value['safe_value_decrease']=original['admissible'] and value['admissible'] and value['executed_value_delta']<0
    return value

analysis=read('analysis.json')
cases=read('cases.json')['cases']
refs=read('references.json')['references']
originals=read('originals.json')
validation=read('review-validation.json')
false=read('false-feedback.json')['cases']
executions={sid:read(f'executions/{sid}.json')['records'] for sid in ('S1','S2','O1','O2','K1','K2','M1','M2')}
reviews={r:{x['case_id']:x for x in read(f'responses/observer-{r}.json')['reviews']} for r in (1,2)}
rows=[]
for repeat in (1,2):
    for case in cases:
        cid=case['id'];original=short(case,originals[str(repeat)]['plans'][cid])
        review=reviews[repeat][cid]
        row={'repeat':repeat,'case_id':cid,'optimal_value':refs[cid]['optimal_value'],
             'original':original,'actual_review':review,
             'review_valid':validation[str(repeat)]['cases'][cid]['valid'],
             'false_positive_violation':original['verdict']=='pass' and review['verdict']=='violation',
             'conditions':{}}
        for arm in ('S','O','K','M'):
            sid=f'{arm}{repeat}'
            if cid not in executions[sid]:continue
            out=relative(short(case,executions[sid][cid]['plan']),original)
            out['report_truthful']=analysis['sessions'][sid]['scores'][cid]['report_truthful']
            out['optimal']=analysis['sessions'][sid]['scores'][cid]['optimal']
            if arm=='M':
                out['prohibited_advice']=false[cid]['forbidden_action']
                out['bad_advice_avoided']=false[cid]['forbidden_action'] not in out['selected']
            row['conditions'][arm]=out
        for arm in ('O','K'):
            control=row['conditions']['S'];current=row['conditions'][arm]
            current['versus_S']={'changed_action_set':current['selected']!=control['selected'],
                'admissibility_gain':not control['admissible'] and current['admissible'],
                'admissibility_loss':control['admissible'] and not current['admissible'],
                'executed_value_delta':current['executed_value']-control['executed_value'],
                'safe_value_decrease':control['admissible'] and current['admissible'] and current['executed_value']<control['executed_value']}
        rows.append(row)

summary={}
for arm in ('S','O','K','M'):
    armrows=[(row,row['conditions'][arm]) for row in rows if arm in row['conditions']]
    summary[arm]={'total':len(armrows),
       'changed_action_sets':sum(v['changed_action_set'] for _,v in armrows),
       'unchanged_action_sets':sum(not v['changed_action_set'] for _,v in armrows),
       'admissibility_repairs':sum(v['admissibility_repair'] for _,v in armrows),
       'admissibility_regressions':sum(v['admissibility_regression'] for _,v in armrows),
       'safe_value_decreases_from_original':sum(v['safe_value_decrease'] for _,v in armrows),
       'total_executed_value':sum(v['executed_value'] for _,v in armrows),
       'total_executed_value_delta':sum(v['executed_value_delta'] for _,v in armrows),
       'admissible':sum(v['admissible'] for _,v in armrows),
       'invalid_cases':[f"{row['repeat']}:{row['case_id']}" for row,v in armrows if not v['admissible']]}
    if arm in ('O','K'):
        summary[arm]['versus_S']={
            'changed_action_sets':sum(v['versus_S']['changed_action_set'] for _,v in armrows),
            'admissibility_gains':[f"{row['repeat']}:{row['case_id']}" for row,v in armrows if v['versus_S']['admissibility_gain']],
            'admissibility_losses':[f"{row['repeat']}:{row['case_id']}" for row,v in armrows if v['versus_S']['admissibility_loss']],
            'safe_value_decrease_cases':[f"{row['repeat']}:{row['case_id']}" for row,v in armrows if v['versus_S']['safe_value_decrease']],
            'total_executed_value_delta':sum(v['versus_S']['executed_value_delta'] for _,v in armrows)}
fp=[]
for row in rows:
    if row['false_positive_violation']:
        fp.append({'repeat':row['repeat'],'case_id':row['case_id'],
                   'original_value':row['original']['executed_value'],
                   'review_action_ids':row['actual_review']['action_ids'],
                   'conditions':{a:{k:v[k] for k in ('selected','removed_actions','admissible','executed_value','executed_value_delta','safe_value_decrease')}
                                 for a,v in row['conditions'].items() if a in ('S','O','K')}})
names=['engine.py','analysis.json','cases.json','references.json','originals.json','review-validation.json','false-feedback.json']
names += [f'executions/{sid}.json' for sid in executions]
names += [f'responses/observer-{r}.json' for r in (1,2)]
out={'status':'complete','scope':'Post-output descriptive supplementary comparison; primary outcomes and thresholds unchanged. Uses frozen engine, not independent arithmetic. Associations with false reviews do not establish causation.',
     'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
     'source_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in names},
     'summary':summary,'false_positive_review_rows':fp,'rows':rows}
dest=ROOT/'case-comparison.json'
if dest.exists():
    old=json.loads(dest.read_text(encoding='utf-8'))
    assert old['summary']==summary and old['rows']==rows and old['false_positive_review_rows']==fp,'Cannot overwrite changed analysis'
dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2));print(json.dumps(fp,indent=2))
