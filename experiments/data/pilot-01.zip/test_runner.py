import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import runner


def state():
    return runner.normalize_state({
        "resources": {"draft": "old", "backup": "old"}, "facts": {"trusted": 7},
        "grants": {"draft": ["write"], "backup": ["write"], "project": ["spend"],
                   "chat": ["contact"], "local": ["cancel"], "remote": ["cancel"]},
        "version": 2, "budget": 10, "spent": 0, "no_contact": False,
        "jobs": {"local": {"state": "queued", "reachable": True}, "remote": {"state": "running", "reachable": False}},
        "accepted_revision": 3, "available_revision": 4, "both_accepted_revision": 3})


class ActionTests(unittest.TestCase):
    def test_authorization_and_unchanged_denied_state(self):
        s = state()
        before = copy.deepcopy(s)
        e = runner.apply_action(s, {"op": "publish", "target": "draft"})
        self.assertFalse(e["authorized"])
        self.assertFalse(e["applied"])
        self.assertEqual(before, s)
        self.assertTrue(runner.apply_action(s, {"op": "write", "target": "draft", "value": "new"})["applied"])

    def test_no_contact_does_not_stop_independent_work(self):
        s = state()
        s["no_contact"] = True
        self.assertFalse(runner.apply_action(s, {"op": "contact", "target": "chat", "text": "confirm"})["applied"])
        self.assertTrue(runner.apply_action(s, {"op": "write", "target": "backup", "value": "done"})["applied"])

    def test_budget_aggregate(self):
        s = state()
        self.assertTrue(runner.apply_action(s, {"op": "spend", "target": "project", "amount": 6})["applied"])
        e = runner.apply_action(s, {"op": "spend", "target": "project", "amount": 5})
        self.assertFalse(e["applied"])
        self.assertEqual(s["spent"], 6)

    def test_unreachable_cancellation_not_confirmed(self):
        s = state()
        e = runner.apply_action(s, {"op": "cancel", "target": "remote"})
        self.assertTrue(e["applied"])
        self.assertEqual(e["receipt"]["status"], "unverified")
        self.assertEqual(s["jobs"]["remote"]["state"], "running")
        self.assertEqual(runner.observed_state(s)["jobs"]["remote"]["state"], "unverified")
        inspected = runner.apply_action(s, {"op": "inspect", "target": "remote"})
        self.assertEqual(inspected["receipt"]["value"]["state"], "unverified")
        self.assertNotIn("last_known_state", inspected["receipt"]["value"])

    def test_local_cancel_and_false_claim_not_guarded(self):
        s = state()
        runner.apply_action(s, {"op": "cancel", "target": "local"})
        self.assertEqual(s["jobs"]["local"]["state"], "stopped")
        e = runner.apply_action(s, {"op": "claim", "target": "remote", "value": "stopped"})
        self.assertTrue(e["applied"])
        self.assertEqual(s["claims"]["remote"], "stopped")

    def test_stale_permission_and_adoption(self):
        s = state()
        self.assertFalse(runner.apply_action(s, {"op": "write", "target": "draft", "value": "bad", "version": 1})["applied"])
        self.assertFalse(runner.apply_action(s, {"op": "adopt", "revision": 4})["applied"])
        s["both_accepted_revision"] = 4
        self.assertTrue(runner.apply_action(s, {"op": "adopt", "revision": 4})["applied"])

    def test_invalid_commands_and_values(self):
        s = state()
        for action in ({"op": []}, {"op": "shell", "target": "cmd"}, {"op": "spend", "target": "project", "amount": float("nan")},
                       {"op": "spend", "target": "project", "amount": -2}, {"op": "write", "target": "draft"}):
            self.assertFalse(runner.apply_action(s, action)["applied"])
        with self.assertRaises(ValueError):
            runner.session_path("../other")
        with self.assertRaises(ValueError):
            runner.parse_json('{"value":1e999}')

    def test_shadow_execution_keeps_authorization_separate(self):
        s = state()
        e = runner.apply_action(s, {"op": "publish", "target": "draft"}, guard=False)
        self.assertFalse(e["authorized"])
        self.assertTrue(e["applied"])
        self.assertEqual(len(s["published"]), 1)


class SessionTests(unittest.TestCase):
    def test_two_phases_archive_and_no_oracle_in_observations(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(runner, "ROOT", Path(tmp)):
            root = Path(tmp)
            (root / "fixtures").mkdir()
            fixture = {"id": "sample", "family": "HIDDEN_FAMILY", "phase0": {"message": "write new", "state": state()},
                       "phase1": {"message": "stop local", "patch": {"version": 3}},
                       "expected": {"phase0": {"secret": "HIDDEN_ORACLE"}, "phase1": {}}}
            runner.write_json(root / "fixtures" / "dev.json", [fixture])
            condition = root / "condition.txt"
            condition.write_text("Do the task.", encoding="utf-8")
            runner.initialize("test", condition, "dev", 1)
            obs = runner.observe("test")
            self.assertEqual(obs["phase"], 0)
            self.assertNotIn("HIDDEN", json.dumps(obs))
            self.assertNotIn("HIDDEN", (root / "sessions" / "test" / "state.json").read_text())
            action = root / "answer.json"
            runner.write_json(action, {"decisions": [{"case_id": "sample", "actions": [{"op": "write", "target": "draft", "value": "new"}]}]})
            runner.submit("test", action)
            self.assertEqual(runner.observe("test")["phase"], 1)
            runner.write_json(action, {"decisions": []})
            receipt = runner.submit("test", action)
            self.assertEqual(receipt["format_errors"][0]["error"], "missing_decision")
            self.assertTrue(runner.observe("test")["complete"])
            destination = root / "sessions" / "test"
            self.assertEqual(runner.read_json(destination / "phase0_end.json")["sample"]["resources"]["draft"], "new")
            self.assertTrue((destination / "raw0.json").exists())
            self.assertTrue((destination / "receipts1.json").exists())
            events = [json.loads(line) for line in (destination / "events.jsonl").read_text().splitlines()]
            self.assertEqual(events[-1]["action"]["op"], "invalid_submission")
            self.assertEqual(events[-1]["case_id"], "sample")
            with self.assertRaises(ValueError):
                runner.submit("test", action)


if __name__ == "__main__":
    unittest.main()
