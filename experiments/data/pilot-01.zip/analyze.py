import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path
import diagnose

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--allow-partial',action='store_true')
    args=parser.parse_args()
    manifest=json.loads((ROOT/'analysis'/'manifest_holdout.json').read_text(encoding='utf-8'))
    changed=[name for name,digest in manifest['hashes'].items() if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest]
    if changed:
        raise RuntimeError('Frozen input changes: '+str(changed))
    sessions=[]
    missing=[]
    all_points=[]
    for row in manifest['schedule']:
        path=ROOT/'sessions'/row['session']
        expected_episodes=6 if row['split']=='dev' else 12
        if not (path/'phase1_end.json').exists():
            missing.append(row['session'])
            continue
        result=diagnose.score_session(row['session'])
        points=result['points']
        by_case=defaultdict(list)
        for p in points:
            by_case[p['case_id']].append(p)
            all_points.append({**p,'session':row['session'],'condition':row['condition'],'split':row['split'],'replicate':row['replicate']})
        sessions.append({**row,**result['summary'],'episodes':expected_episodes,
                         'episodes_pass':sum(len(ps)==2 and all(p['overall_pass'] for p in ps) for ps in by_case.values()),
                         'episodes_goal_pass':sum(len(ps)==2 and all(p['goal_pass'] for p in ps) for ps in by_case.values())})
    if missing and not args.allow_partial:
        raise RuntimeError('Missing sessions: '+str(missing))
    grouped=[]
    sums=['points','overall_pass','goal_pass','episodes','episodes_pass','episodes_goal_pass',
          'unauthorized_attempts','unauthorized_executed','unsupported_status_reports','invalid_actions','pause_actions','action_count']
    for split in ['dev','holdout']:
        for condition in ['B','N','U','D']:
            chosen=[x for x in sessions if x['split']==split and x['condition']==condition]
            grouped.append({'split':split,'condition':condition,'sessions':len(chosen),
                            **{key:sum(x[key] for x in chosen) for key in sums}})
    failures=[p for p in all_points if not p['overall_pass']]
    result={'sessions':sessions,'by_condition':grouped,'failed_points':failures,'missing_sessions':missing,
            'totals':{key:sum(s[key] for s in sessions) for key in sums},'frozen_hashes_match':not changed,
            'interpretation':'Descriptive clustered pilot. No significance claim, no independent-model claim.'}
    (ROOT/'analysis'/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'analysis'/'points.json').write_text(json.dumps(all_points,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'by_condition':grouped,'missing_sessions':missing,'failed_points':
                     [{'session':p['session'],'case_id':p['case_id'],'phase':p['phase'],
                       'codes':[i['code'] for i in p['issues']]} for p in failures]},indent=2))


if __name__=='__main__':
    main()
