# Reading and replaying the UCP pilot

This directory contains synthetic data only. Start with [the Russian report](REPORT.ru.md), [the fixed plan](PLAN.md), and [the debugging profile](DEBUG_PROTOCOL.ru.md).

The experiment is complete. Replaying analysis is different from generating new model responses. The twelve recorded model sessions must remain unchanged, including the failed responses.

## Environment

The scripts use Python standard-library modules. Python 3.11 or later is suitable. They were executed through Windows PowerShell. No OpenRouter credentials or external model API are required to replay recorded results.

Model participants were fresh subagents using an inherited backend. Its exact model revision, sampling parameters and sampling seed were not exposed. Order seeds are stored, but they do not make a fresh model generation deterministic.

## Preserve the original bundle

Use a working copy of this entire directory before running scripts that write derived files. `analyze.py` rewrites `analysis/results.json` and `analysis/points.json`. The diagnostic scripts rewrite their result and fixture files. The original bundle's final hashes are in `analysis/completion.json`.

Do not run `prepare.py` or `freeze_holdout.py` in the completed directory. Those scripts document historical preparation and create named sessions. Reusing an existing session is rejected. Do not delete sessions to make these commands run.

## Replay checks in a working copy

From the copied directory:

```powershell
python -m unittest test_runner -v
python test_diagnostics.py --split dev
python test_diagnostics.py --split holdout
python metamorphic_check.py
python analyze.py
```

Expected results:

- 9 runner unit tests pass.
- Each diagnostic split finds 8 injected faults, misses 0 and flags 0 of 8 correct controls.
- Guard-label inversion leaves all 16 diagnoses per split unchanged.
- 17 metamorphic checks pass.
- Analysis finds all 12 planned sessions, 120 episodes, 240 phases, 117 passing episodes, 237 passing phases and 5 invalid actions.
- Frozen hashes match. The holdout episode totals are B 23/24, N 24/24, U 24/24, D 23/24.

The reference selfcheck uses supplied actions, not a model. `analysis/repair_replay.json` is a controlled mechanical replay, not an extra model session or an autonomous repair attempt.

## Evidence layout

- `protocol/`: exact instruction packages and the copied UCP README.
- `fixtures/`: development and holdout cases, expected outcomes, reference actions and diagnostic records.
- `sessions/<name>/packet.txt`: participant package.
- `sessions/<name>/raw0.json`, `raw1.json`: submitted responses.
- `sessions/<name>/events.jsonl`: commands, pre/post state and receipts.
- `sessions/<name>/phase0_end.json`, `phase1_end.json`: states used for scoring.
- `analysis/manifest_initial.json`, `manifest_holdout.json`: frozen schedules and SHA-256 hashes.
- `analysis/metadata_addendum.json`: factual correction of the D v2 package length, without rewriting the frozen manifest.
- `analysis/final_audit.md`: separate reviewer findings.
- `analysis/completion.json`: final completion status and hashes of the bundle.

The fixture expectations are part of the test design. They are not available in an arbitrary live conversation. The diagnostic holdout changes parameters of the same eight templates, so its perfect score is a finite implementation check, not a claim of general semantic fault detection.

## Creating a later experiment

Use a new directory, a new fixed plan, named hypotheses and explicit stopping criteria. Keep this pilot's failed examples as development material, not fresh holdout evidence. No later experiment was started as part of this delivery.
