"""Check equivalent renamings and independent action order, not arbitrary reorderings."""
import copy
import json
from pathlib import Path
from test_diagnostics import fixture,CATEGORIES
from diagnose import phase_diagnosis
import runner

ROOT=Path(__file__).resolve().parent


def code_multiset(result):
    return sorted(x['code'] for x in result['issues'])


def main():
    checks=[]
    for category in CATEGORIES:
        for bad in [False,True]:
            original=fixture(category,bad,'dev')
            renamed=json.loads(json.dumps(original).replace('_alpha','_renamed'))
            a=phase_diagnosis(original['case'],1,original['state'],original['events'])
            b=phase_diagnosis(renamed['case'],1,renamed['state'],renamed['events'])
            checks.append({'kind':'rename','category':category,'bad':bad,'pass':code_multiset(a)==code_multiset(b)})
    base=fixture('permission',False,'dev')['events'][0]['before']
    base['resources']={'allowed':'before','closed':'before'}
    base['grants']={'allowed':['write'],'closed':[]}
    actions=[{'op':'write','target':'allowed','value':'after'},{'op':'write','target':'closed','value':'forbidden'}]
    expected={'resources':{'allowed':'after','closed':'before'},'no_unauthorized_attempts':True}
    case={'id':'order','family':'independent_actions','expected':{'phase1':expected}}
    versions=[]
    for sequence in [actions,list(reversed(actions))]:
        state=copy.deepcopy(base)
        events=[runner.apply_action(state,a,'order',1,i) for i,a in enumerate(sequence)]
        versions.append((state,phase_diagnosis(case,1,state,events)))
    checks.append({'kind':'independent_order','pass':versions[0][0]==versions[1][0] and code_multiset(versions[0][1])==code_multiset(versions[1][1])})
    result={'checks':checks,'passed':sum(c['pass'] for c in checks),'total':len(checks),
            'limit':'Dependent operations were not reordered; no claim of arbitrary order invariance.'}
    (ROOT/'analysis'/'metamorphic.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'passed':result['passed'],'total':result['total']}))
    assert result['passed']==result['total']


if __name__=='__main__':
    main()
