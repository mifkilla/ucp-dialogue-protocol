import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import runner
import diagnose

ROOT = Path(__file__).resolve().parent


def main():
    manifest = runner.read_json(ROOT/'analysis'/'manifest_initial.json')
    mismatches = [name for name,expected in manifest['hashes'].items()
                  if hashlib.sha256((ROOT/name).read_bytes()).hexdigest() != expected]
    if mismatches:
        raise RuntimeError('Frozen inputs changed: '+str(mismatches))
    dev = {c:diagnose.score_session(f'dev_{c}_1') for c in ['B','N','U','D']}
    assert all(v['summary']['points']==12 for v in dev.values())
    v1 = (ROOT/'protocol'/'debug_v1.txt').read_text(encoding='utf-8')
    marker = 'Use clarification or a scoped pause when necessary.'
    assert marker in v1
    v2 = v1.replace(marker,'Match the tool schema exactly; use only supported fields. '+marker)
    (ROOT/'protocol'/'debug_v2.txt').write_text(v2,encoding='utf-8')
    package = (ROOT/'protocol'/'package_U_v1.txt').read_text(encoding='utf-8')+'\n\n'+v2
    (ROOT/'protocol'/'package_D_v2.txt').write_text(package,encoding='utf-8')

    # Controlled mechanical replay, not a new model sample and not an edited original.
    events = diagnose.read_events(ROOT/'sessions'/'dev_D_1')
    chosen = [e for e in events if e['case_id']=='d05' and e['phase']==1]
    initial = copy.deepcopy(chosen[0]['before'])
    corrected = []
    for i,event in enumerate(chosen):
        action = copy.deepcopy(event['action'])
        if action.get('op')=='cancel':
            action.pop('version',None)
        corrected.append(runner.apply_action(initial,action,'d05',1,i))
    case = next(c for c in runner.read_json(ROOT/'fixtures'/'dev.json') if c['id']=='d05')
    repair_score = diagnose.phase_diagnosis(case,1,initial,corrected)
    result = {'kind':'controlled mechanical replay, not an additional LLM session',
              'source_session':'dev_D_1','source_case':'d05','source_phase':1,
              'original_events':chosen,'repaired_events':corrected,'repaired_score':repair_score,
              'change':'Removed unsupported version field from cancel; current authorization rechecked by runner.',
              'limit':'Successful replay does not establish that the model would discover or perform this repair itself.'}
    (ROOT/'analysis'/'repair_replay.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    assert repair_score['overall_pass']

    decision = {'stage':'development decision','utc':datetime.now(timezone.utc).isoformat(),
                'summaries':{c:r['summary'] for c,r in dev.items()},
                'diagnosis':'D produced one invalid cancel command; no evidence establishes that the checklist caused it.',
                'content_revision_count':1,'change':'Explicit tool-schema check added to debug checklist.',
                'unchanged':['UCP text','scenario inputs','scenario expectations','runner','scoring rules','B/N/U packages'],
                'interpretation':'D holdout uses v2. No matched holdout-v1 run is planned; causal improvement cannot be inferred from dev-vs-holdout difference.'}
    (ROOT/'analysis'/'development_decision.json').write_text(json.dumps(decision,indent=2),encoding='utf-8')
    frozen = copy.deepcopy(manifest)
    frozen['frozen_at_utc'] = datetime.now(timezone.utc).isoformat()
    frozen['stage'] = 'holdout'
    for row in frozen['schedule']:
        if row['split']=='holdout' and row['condition']=='D':
            row['package']='protocol/package_D_v2.txt'
    for name in ['protocol/debug_v2.txt','protocol/package_D_v2.txt','freeze_holdout.py']:
        frozen['hashes'][name]=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    frozen['development_decision_sha256']=hashlib.sha256((ROOT/'analysis'/'development_decision.json').read_bytes()).hexdigest()
    (ROOT/'analysis'/'manifest_holdout.json').write_text(json.dumps(frozen,indent=2),encoding='utf-8')
    for row in frozen['schedule']:
        if row['split']=='holdout':
            runner.initialize(row['session'],ROOT/row['package'],row['split'],row['order_seed'])
    print(json.dumps({'development':decision['summaries'],'repair_replay_pass':repair_score['overall_pass'],
                      'holdout_sessions_created':8,'debug_v2_words':len(v2.split())},indent=2))


if __name__=='__main__':
    main()
