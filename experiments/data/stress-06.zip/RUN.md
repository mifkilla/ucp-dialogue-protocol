# Stress pilot run record

Local date: 2026-11-23 Moscow (2026-11-22 UTC). This follows the completed research-2026-11-22 snapshot under a new user request. It does not replace or alter that release.

The local prospective plan was recorded before implementation. Eighteen inputs were frozen before participant generation. The exact UTC freeze timestamp and file hashes are in `manifest.json`. This is local prospective fixation, not external public preregistration. The manifest SHA-256 is `8ed13410ad0fb0bbc2ff191c86eca7792e696dcfbecf76fb49d86cda5da52aa5`.

Participants are fresh runtime subagent sessions with no inherited conversation history. Model overrides were not selected; exact backend snapshot and sampling parameters were not exposed. No OpenRouter call was made. Order seeds control presentation only. Isolation is an instruction on a shared filesystem, not a security sandbox.

The launcher directs each participant to its own packet and output path, requires complete per-case reading to avoid truncation, forbids solver code and other files, and asks for literal JSON only. Public output contains structured decisions and brief review explanations, not private reasoning. All cases are synthetic. No real external application action occurs.

## Infrastructure event

Both initial actors reported that their literal JSON responses were already chosen, but saving failed because the host had not created the `responses` directory. Initial-1 reported one failed save; initial-2 reported two failed save methods. No response file existed. The host created the directory and asked both to write their already chosen response unchanged, without reconsideration or resampling. This is a host file-setup failure, not a model content retry or a repaired experimental answer. Frozen inputs and prompts were not changed.

Revision participants S1, O1 and K2 reported that an initial whole-packet display was truncated and that they then reread each case separately in full before responding. Complete chunked reading, not the truncated display, is the specified input procedure. These were input-reading corrections, not output resampling.

## Interpretation boundary

The first proposal is a dry run. A later correction is repair of a model's own proposal, not reversal of an executed harmful effect. S receives a substantive checklist; O adds an actual separate model review; K adds deterministic facts and diagnostics computed from the same public data. K receives no optimal solution. These interventions differ in added information and computation. No claim is made about pure UCP wording, a role-name effect, or an unrestricted coding agent.

The false-feedback block is distinct and organizer-authored. It uses exact quotations with an invalid permission conclusion. It must not be counted as an error of the actual observer.

Independent arithmetic uses a separate implementation. The reviewer also participated in preflight and knew the references, so semantic review is not blind external validation. Case families share templates. Results describe the fixed cases and session clusters, not a population of all dialogues.

## Completion

All planned 24 original proposals, 24 actual observer reviews, 80 revised plans and 80 final structured reports are present. The original proposals were all admissible and optimal; all 80 revised action sets stayed unchanged. S/O/K each achieved 24/24 joint successes and the organizer-authored false-feedback controls achieved 8/8. No condition met the added-benefit criterion. Own-error repair and violation-detection precision/recall have zero denominators and are null.

The independent audit found no discrepancy with the primary analysis. It checked the frozen inputs and subsequent evidence manifests, 49,152 reference subsets, 72 exact quotations, 80 receipts and 80 reports. A separate nonblind review assessed all 24 observer explanations. See AUDIT.md and review-semantics.json for their exact scope. No further model trials are part of this run.
