# Run record: final UCP integration pilot

Date: 2026-11-22. This archive records one bounded run. Its inputs were frozen locally at 16:49:59 UTC, before either observer was started. The plan was recorded before implementation. This is prospective local fixation, not an external preregistration or a claim that the archive was publicly available before generation.

## Participants and isolation

Six fresh runtime subagent sessions were used: two observers (`final_obs1`, `final_obs2`) and four executors (`final_c1`, `final_o1`, `final_c2`, `final_o2`). Their initial sessions inherited no conversation history. No model override was selected. The runtime backend, exact model snapshot and sampling settings were not exposed in the experiment's result record. This is not a comparison across independently selected architectures. No OpenRouter call was used.

Each observer was allowed to read only its packet and write its response. Each executor was allowed to read only its own current-round packet and write its own response. The launcher did not provide reference labels or obligations. It stated the isolation boundary, requested all 12 cases and named the output file. The role-specific instructions and full actual inputs are included in `packets/`. These file restrictions were instructions to the participants, not an operating-system sandbox. The public result files do not independently establish that no unrecorded access occurred.

Executor rounds continued in the same participant session to supply the actual simulator receipt. Every executor got two action rounds and one final report-only round. The host applied the fixed simulator and did not substitute its own corrected decisions. Histories contain organizer-supplied past assistant proposals, not the new participant's spontaneous earlier errors.

All 24 observer assessments, 96 action decisions and 48 final reports were returned. No formatting retry, replacement participant, outcome-driven rerun or post-output prompt/reference/scorer adjustment was used. Public JSON explanations are retained. Private reasoning is neither requested nor included.

## Integrity and review

`manifest.json` fixes the 14 initial inputs. `treatment-manifest.json` fixes actual observer outputs and the derived initial executor packets before executors begin. Eight `stage-*.json` files bind each round's input response, generated receipt and next packet. `semantic-review.json` binds both observer responses and four final-report responses to a separate assessment of meaning and truthfulness. `bundle_hashes.json` covers all packaged files except itself.

The semantic reviewer also participated in preflight review and knew the reference outcomes. Its judgment is an additional check, not blind independent ground truth or human annotation. The standalone audit uses separate code to recalculate saved transitions and metrics; this is an independent implementation check within the same AI-assisted workflow, not an external laboratory replication.

The run has two observer sessions and four executor sessions. Cases repeat within those sessions. Counts across cases must not be treated as independent population replications. Seeds control order only. The observer condition includes additional diagnostic content and length; `packet-lengths.json` reports the actual initial packets.

The final interpretation is in the repository's bilingual `experiments/final/RESULTS` documents. This archive supports reproduction of saved calculations, not identical regeneration of stochastic model answers. The current testing phase ends with the research snapshot. No automatic experiment, background monitoring or unsolicited contact remains running for this project.
