# Observer 04 evidence bundle

Read REPORT.md or REPORT.ru.md. Inputs are synthetic cases and anonymized
historical reconstructions. Original private transcripts are not included.
Two sessions on the same 30 prepared cases do not establish general accuracy.

Python 3.11+, standard library only. From a new extracted directory:

```powershell
python -B -m unittest discover -v
python -B evaluate.py verify .
python -B evaluate.py analyze .
python -B check_artifacts.py artifacts.json
python -B audit.py
python -B observe.py packet-A.json responses/A.json --out replay-observer.json
```

These commands make no model calls. Do not prepare over this completed run.
manifest.json covers frozen inputs. bundle_hashes.json covers packaged evidence
except itself. Neither file is a cryptographic identity signature.

Current project: https://github.com/mifkilla/ucp-dialogue-protocol
