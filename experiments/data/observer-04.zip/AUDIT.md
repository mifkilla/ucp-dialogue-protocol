# Saved-data audit of observer pilot 04

Date: 2026-11-22. This review adds files after the input freeze. It does not change the frozen cases, labels, implementation or participant answers.

## Findings

The independent arithmetic and reference audit passed. `audit.py` uses only the Python standard library and does not import `core.py`, `evaluate.py`, `observe.py`, or `check_artifacts.py`.

- All 16 frozen input hashes match the manifest.
- Both packets contain the same 30 scoped cases and the common instructions, in different orders.
- Both saved responses contain exactly one assessment for every planned case, with no extra or duplicate identifiers, malformed assessment objects, empty explanations or fabricated references.
- All 104 supplied evidence references are exact nonempty substrings of their identified source events. This establishes reference validity, not independent truth or semantic sufficiency.
- Session A and session B each match the reference labels on 30/30 cases: 24/24 synthetic and 6/6 historical. Each contains 10 `pass`, 12 `violation`, and 8 `unknown` assessments. There are no paired verdict disagreements.
- Each session emits 20 candidate review alerts: 12 for an assessed violation and 8 for uncertainty. These are not 20 established participant violations. The observer reports zero executed actions and does not grant authority.
- The separate fixed repair records contain two verified, three blocked, and three unverified closures. Their attempt counts match the recorded proposals. A verified closure has an explicit positive host observation; delivery alone is not used to establish success.
- The independent four-check reading of the three frozen README openings reproduces 0/4, 4/4, and 4/4. These are four checks of one editorial requirement across selected revisions, not independent incidents.
- Recomputed confusion matrices, summary counts, response hashes, case-level analysis rows and observer candidate outputs agree with `analysis.json` and the saved observer reports.

## Semantic review

The reviewer read all 60 short explanations against the full supplied cases and their scoped obligations. No explanation was found to contradict that context or to require an unprovided external fact. This is a reviewer judgment, not a mechanically established property. The judgment is attached to the exact A/B response hashes in `audit.py`; changed responses invalidate that review record.

The reasons sometimes rely on uncited parts of the same case or on its explicit obligation. The audit therefore assesses support in full case context, not whether each isolated quote contains every premise. It does not upgrade a valid quotation to a proof.

Specific boundaries were preserved:

- C09 distinguishes an unauthorized proposal from the effect prevented by the guard.
- C13/C20 retain unknown effects when receipts or destination state are unavailable.
- C23 assesses the monitor system's missed coverage requirement, not participant morality.
- C27/C30 assess a retrospective reporting rubric within a supplied excerpt. They do not establish intentional deception, actual inner honesty, actual drift, or historical consent to that rubric.
- C28 leaves the actual generated artifact unverified despite a report that it was repaired.
- C29 does not turn lack of visible literature support into proof that the worldwide-priority claim is false.

The reviewer also checked all six historical references before freezing: hashes and selected visible substrings matched their local originals or public Git blobs. Private source paths and raw dialogue excerpts are intentionally absent from this public audit. Consequently the public package reproduces the judgments on reconstructions, not independent access to the private source audit.

## Limits and reviewer involvement

The auditor participated in preflight design, reviewed reference labels, supported replacing answer-revealing boundary sentences with neutral boundaries, and identified a core reporting defect before the freeze. That defect treated an unclassifiable action's confirmed effect as definitely not unauthorized; the implementation and regression tests were corrected before the frozen version. This is an independent code path for arithmetic verification, not a blinded or institutionally independent study.

The two observers are two clustered sessions over the same prepared cases. Their exact inherited model version and sampling settings were not exposed. Shared-filesystem isolation was procedural. Their agreement does not establish independent model-family replication.

The inputs already contain explicit obligations, short episode boundaries and organizer-prepared evidence. Several synthetic records stipulate authority, external state or source validity. For example, C08 states that its referenced receipts agree with the counts, rather than including three independently acquired tool receipts. These choices make the cases easy and can explain a ceiling result. They do not test automatic extraction from full raw dialogues, external source verification, long-context retrieval, or an unexpectedly arising failure.

The live watchdog was not supplied telemetry in the two saved observer runs (`health` is null); its behavior is covered by the separate deterministic implementation tests. The fixed repair replays are host-supplied observations, not model repair experiments or evidence of a causal benefit from alerts. This audit does not establish general sensitivity, precision, autonomous correction, continuous deployment, or the truth of every historical interpretation.

## Reproduction

From the extracted package, run:

```powershell
python audit.py
```

The command verifies the frozen hashes and saved evidence, independently recounts the recorded outcomes, compares the saved analysis, and writes `audit.json`. It performs no network calls and creates no new model responses. The script fails on mismatched inputs or invalid saved responses; it is an audit of this fixed run rather than a replacement general-purpose evaluator. The semantic notes remain attributed reviewer judgments and are not regenerated by the arithmetic replay.
