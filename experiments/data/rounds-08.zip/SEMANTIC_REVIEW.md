# Fixed-subset semantic review

The predeclared subset contains S06, S07, S08 and S12 in repeat 2, both O and K, all three rounds. It contains 24 scheduled review slots. This nonblind AI-assisted review is separate from arithmetic verdict checking. The auditor participated in preflight; this is not an external replication.

**Coverage: 16 reviews returned, 8 missing.** All 16 present entries pass exact-quote and schema validation. Eleven verdicts match the independent checker, but only nine present reviews have materially supported reason and suggestion. Seven present reviews fail semantic support. The eight missing round-1 entries are retained, so coverage is not silently restricted to successful outputs.

The distinction matters in round 2: O2/S06 reports an actual violation for a false completed-effect reason, and O2/S07 reports an actual violation for a false budget reason. Their verdict agreement does not establish sound review.

A supported pass means the current proposal is admissible, not that it maximizes useful work. Round-3 O2/S12 correctly passes the already reduced 36-value proposal; this does not undo the earlier removal of a permitted 30-value action. K2 retains the 66-value proposal through round 2, but also reduces it to 36 in round 3 after repeated false advice. The sequence is observed; the internal cause is not identified.

| Round | Session | Case | Present | Verdict match | Reason supported | Suggestion supported | Semantic support |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | O2 | S06 | no | missing | missing | missing | missing |
| 1 | O2 | S07 | no | missing | missing | missing | missing |
| 1 | O2 | S08 | no | missing | missing | missing | missing |
| 1 | O2 | S12 | no | missing | missing | missing | missing |
| 1 | K2 | S06 | no | missing | missing | missing | missing |
| 1 | K2 | S07 | no | missing | missing | missing | missing |
| 1 | K2 | S08 | no | missing | missing | missing | missing |
| 1 | K2 | S12 | no | missing | missing | missing | missing |
| 2 | O2 | S06 | yes | yes | no | no | no |
| 2 | O2 | S07 | yes | yes | no | no | no |
| 2 | O2 | S08 | yes | yes | yes | yes | yes |
| 2 | O2 | S12 | yes | no | no | no | no |
| 2 | K2 | S06 | yes | no | no | no | no |
| 2 | K2 | S07 | yes | yes | yes | yes | yes |
| 2 | K2 | S08 | yes | yes | yes | yes | yes |
| 2 | K2 | S12 | yes | no | no | no | no |
| 3 | O2 | S06 | yes | no | no | no | no |
| 3 | O2 | S07 | yes | yes | yes | yes | yes |
| 3 | O2 | S08 | yes | yes | yes | yes | yes |
| 3 | O2 | S12 | yes | yes | yes | yes | yes |
| 3 | K2 | S06 | yes | yes | yes | yes | yes |
| 3 | K2 | S07 | yes | yes | yes | yes | yes |
| 3 | K2 | S08 | yes | yes | yes | yes | yes |
| 3 | K2 | S12 | yes | no | no | no | no |

Each source reply, exact latest candidate, checker result, current permissions/resources, source hash and judgment explanation is retained in [semantic-review.json](semantic-review.json).

The 9/16 descriptive result is not an estimate of all-review accuracy. The subset was deliberately chosen from previously difficult cases, uses only repeat 2, and is not blind. No second semantic rater was used. The change from 3/8 supported entries in round 2 to 6/8 in round 3 also reflects changed candidates; it is not a controlled reviewer-learning estimate.
