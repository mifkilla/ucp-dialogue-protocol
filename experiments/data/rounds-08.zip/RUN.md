# Completed bounded run

This evidence snapshot records exactly three rounds of GPT-4o revision on the same 24 original proposals, followed by one final simulated execution and a receipt-grounded report. It is known-set development, not an unseen evaluation.

Read `PLAN.md`, `analysis.json`, `METHOD_AUDIT.md` and `SEMANTIC_REVIEW.md`. `CASES.md` and `case_comparison.py` are explicitly supplementary post-output analysis. `provider-preflight.json` records the prior HTTP 400 integration rejection, the pre-generation amendment and the budget carried into this run. Its private raw error is represented by an excerpt and SHA-256, with the API account identifier omitted.

- All 36 planned generation calls completed without retries. Including the preceding rejected request: 37 HTTP attempts, $14.87104 reserved against an $18 bound.
- Returned usage for the completed calls: $4.170006225. The rejected request returned no cost.
- All 216 revised plans and 72 final reports are present. There are 122 actual reviews and 22 missing slots out of 144 scheduled.
- Final S/O/K admissibility: 21/24, 22/24, 24/24. Useful-value ratios: 0.4590322345, 0.4003604224, 0.5384420809.
- Only K passed the new prospective admissibility/utility gate. No optimal plans or full optimal joint successes occurred. All final reports matched the simulator receipts.
- K's useful value decreased from round 2 to round 3. This run does not validate automatic stopping on stagnation or a monotonic improvement rule.

The frozen code and inputs were unchanged after generation. The repository has 222 passing local regression tests; this extracted bundle has 86 tests including the unchanged source engine/pipeline and new round regressions. Independent arithmetic and saved-data replay are separate from new model generation.

Offline reproduction from a fresh extraction, Python 3.11+:

```powershell
python -B -m unittest test_engine test_pipeline test_round_pipeline test_round_transport test_audit_rounds
python -B reference_audit.py
python -B round_pipeline.py verify .
python -B round_pipeline.py analyze .
python -B audit_rounds.py .
python -B audit_rounds.py . --api-only
python -B case_comparison.py --output-dir case-replay
```

Compare every file listed in `bundle_hashes.json` before and after replay. Compare `case-replay/case-comparison.json` and `case-replay/CASES.md` with the included originals. Do not run preparation, generation or execution commands against the completed evidence. No API key is needed for the commands above. The invitation remains open; this snapshot does not start further experiments or background contact.
