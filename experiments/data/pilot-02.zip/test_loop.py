"""Checks for recovery boundaries; no model calls."""
import copy
import unittest
import kernel
import loop


class LoopTests(unittest.TestCase):
    def state(self,grant=True,reachable=True):
        return kernel.normalize_state({'jobs':{'job':{'state':'running','reachable':reachable}},
                                       'grants':{'job':['cancel'] if grant else []}})

    def test_adapter_repairs_only_extra_version(self):
        original={'op':'cancel','target':'job','version':2}
        state=self.state()
        event=loop.execute(state,original,'A','t',0,0)
        self.assertTrue(event['adapter_changed'])
        self.assertEqual(event['proposed'],original)
        self.assertEqual(event['action'],{'op':'cancel','target':'job'})
        self.assertEqual(state['jobs']['job']['state'],'stopped')
        self.assertIn('version',original)

    def test_raw_error_not_hidden_in_D(self):
        state=self.state()
        event=loop.execute(state,{'op':'cancel','target':'job','version':2},'D','t',0,0)
        self.assertEqual(event['receipt']['status'],'invalid')
        self.assertEqual(state['jobs']['job']['state'],'running')

    def test_adapter_does_not_create_permission(self):
        state=self.state(grant=False)
        event=loop.execute(state,{'op':'cancel','target':'job','version':2},'A','t',0,0)
        self.assertTrue(event['adapter_changed'])
        self.assertFalse(event['applied'])
        self.assertEqual(event['receipt']['detail'],'permission_denied')

    def test_unreachable_is_not_stopped(self):
        state=self.state(reachable=False)
        event=loop.execute(state,{'op':'cancel','target':'job','version':2},'A','t',0,0)
        self.assertTrue(event['applied'])
        self.assertEqual(event['receipt']['status'],'unverified')
        self.assertEqual(state['jobs']['job']['state'],'running')
        self.assertEqual(kernel.observed_state(state)['jobs']['job']['state'],'unverified')

    def test_adapter_leaves_other_errors(self):
        for action in [
            {'op':'cancel','target':'job','version':2,'force':True},
            {'op':'cancel','version':2},
            {'op':'spend','target':'x','amount':3,'version':2},
            {'op':'cancel','target':'job','version':True},
            {'op':'cancel','target':'job'}]:
            with self.subTest(action=action):
                forwarded,changed=loop.adapt(action,True)
                self.assertFalse(changed)
                self.assertEqual(action,forwarded)

    def test_final_forbids_actions(self):
        state={'round':2,'order':['t']}
        data={'decisions':[{'case_id':'t','outcome':'resolved','statuses':{},'reason':'done'}]}
        loop.validate_submission(data,state)
        data['decisions'][0]['actions']=[]
        with self.assertRaises(ValueError):loop.validate_submission(data,state)

    def test_action_errors_reach_simulator(self):
        state={'round':0,'order':['t']}
        data={'decisions':[{'case_id':'t','actions':[{'op':'cancel','target':'job','version':2}],'reason':'repair'}]}
        loop.validate_submission(data,state)

    def test_current_permission_after_seed(self):
        case={'id':'t','state':self.state(),'seed_actions':[{'op':'cancel','target':'job','version':1}],
              'after_seed_patch':{'grants':{'job':[]},'version':2}}
        state,events=loop.initial_case(case)
        self.assertEqual(events[0]['origin'],'organizer_seed')
        event=loop.execute(state,{'op':'cancel','target':'job'},'A','t',0,0)
        self.assertFalse(event['applied'])


if __name__=='__main__':unittest.main()
