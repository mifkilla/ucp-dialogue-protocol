"""Re-score fixed recorded responses; no new model calls."""
import json
from pathlib import Path
import loop

ROOT=Path(__file__).resolve().parent
METRICS=['goal_pass','recovery_pass','report_pass','overall_pass','false_success','proposed_schema_errors',
         'forwarded_schema_errors','boundary_attempts','boundary_effects','unsupported_intermediate_claims',
         'final_status_mismatches','unsupported_final_status_claims','new_semantic_errors','adapter_changes',
         'actions','excess_nonidempotent','first_round_failed','first_round_proposal_error','own_round_recovery']


def main():
    manifest=loop.read(ROOT/'analysis/manifest.json')
    changed=[f for f,h in manifest['hashes'].items() if loop.sha(ROOT/f)!=h]
    if changed:raise ValueError('Frozen file changed: '+str(changed))
    sessions=[];missing=[];records=[]
    for row in manifest['schedule']:
        if not loop.read(ROOT/'sessions'/row['session']/'private_state.json')['complete']:
            missing.append(row['session']);continue
        scored=loop.score(row['session'])
        sessions.append({**row,**scored})
        for episode in scored['episodes']:records.append({**row,**episode})
    grouped=[]
    for c in ['R','D','A']:
        selected=[r for r in records if r['condition']==c]
        grouped.append({'condition':c,'episodes':len(selected),**{m:sum(r[m] for r in selected) for m in METRICS},
                        'resolved_reports':sum(r['report_pass'] and r['final']['outcome']=='resolved' for r in selected),
                        'correct_blocked_reports':sum(r['report_pass'] and r['final']['outcome']=='blocked' for r in selected),
                        'correct_unverified_reports':sum(r['report_pass'] and r['final']['outcome']=='unverified' for r in selected)})
    result={'sessions':sessions,'by_condition':grouped,'missing_sessions':missing,'frozen_hashes_match':True,
            'totals':{'sessions':len(sessions),'episodes':len(records),**{m:sum(r[m] for r in records) for m in METRICS}},
            'limits':'Descriptive clustered pilot of organizer-seeded failures. Same inherited backend. No independent-model, significance or equivalence claim.'}
    loop.write(ROOT/'analysis/results.json',result)
    print(json.dumps({'by_condition':grouped,'missing_sessions':missing,'totals':result['totals']},indent=2))


if __name__=='__main__':main()
