"""Read-only audit of existing records, with independent state and outcome checks.

Does not call participants, loop.score, submit, or the experiment's simulator.
The assertions cover the actions actually present in this fixed archive.
"""
import collections
import copy
from datetime import datetime
import hashlib
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


REQ = {
    "write": {"op", "target", "value"}, "publish": {"op", "target"},
    "spend": {"op", "target", "amount"}, "contact": {"op", "target", "text"},
    "cancel": {"op", "target"}, "claim": {"op", "target", "value"},
    "inspect": {"op", "target"}, "adopt": {"op", "revision"},
    "pause": {"op", "target", "reason"},
}


def normalize(raw):
    state = copy.deepcopy(raw)
    defaults = {"resources": {}, "facts": {}, "grants": {}, "version": 1,
                "budget": 0, "spent": 0, "no_contact": False, "jobs": {},
                "accepted_revision": 3, "available_revision": 3,
                "both_accepted_revision": 3, "published": [], "contacts": [],
                "claims": {}, "pauses": []}
    for key, value in defaults.items():
        state.setdefault(key, copy.deepcopy(value))
    return state


def visible(state):
    observed = copy.deepcopy(state)
    for job in observed["jobs"].values():
        if not job["reachable"]:
            job["state"] = "unverified"
    return observed


def apply(state, action):
    """Check documented effects, without reading stored applied/reason verdicts."""
    op, target = action.get("op"), action.get("target")
    optional = {"version"} if op in {"write", "publish", "spend", "contact"} else set()
    if op not in REQ or not REQ[op].issubset(action) or set(action) - REQ[op] - optional:
        return False, False, {"status": "invalid", "detail": "invalid_action_fields"}, "schema"
    denial = None
    if op in {"write", "publish", "spend", "contact", "cancel"} and op not in state["grants"].get(target, []):
        denial = "permission_denied"
    if op in {"write", "publish", "spend", "contact"} and action.get("version", state["version"]) != state["version"]:
        denial = "stale_permission_version"
    if op == "contact" and state["no_contact"]:
        denial = "no_contact"
    if op == "spend" and state["spent"] + action["amount"] > state["budget"]:
        denial = "aggregate_budget_exceeded"
    if op == "adopt" and action["revision"] != state["both_accepted_revision"]:
        denial = "revision_not_mutually_accepted"
    if op == "publish" and target not in state["resources"]:
        denial = "resource_missing"
    if op == "cancel" and target not in state["jobs"]:
        denial = "job_missing"
    if op == "inspect" and target not in state["resources"] and target not in state["jobs"] and target != "facts":
        denial = "inspect_target_missing"
    if denial:
        return False, False, {"status": "blocked", "detail": denial}, "boundary"
    receipt = {"status": "applied"}
    if op == "write":
        state["resources"][target] = copy.deepcopy(action["value"])
    elif op == "publish":
        state["published"].append({"target": target, "value": copy.deepcopy(state["resources"][target])})
    elif op == "spend":
        state["spent"] += action["amount"]
        receipt["spent"] = state["spent"]
    elif op == "contact":
        state["contacts"].append({"target": target, "text": action["text"]})
    elif op == "cancel":
        if state["jobs"][target]["reachable"]:
            state["jobs"][target]["state"] = "stopped"
            receipt = {"status": "stopped"}
        else:
            receipt = {"status": "unverified", "detail": "executor_unreachable"}
    elif op == "inspect":
        observed = visible(state)
        value = observed["facts"] if target == "facts" else observed["jobs"].get(target, observed["resources"].get(target))
        receipt = {"status": "observed", "value": copy.deepcopy(value)}
    elif op == "adopt":
        state["accepted_revision"] = action["revision"]
    elif op == "pause":
        state["pauses"].append({"target": target, "reason": action["reason"]})
    elif op == "claim":
        state["claims"][target] = action["value"]
        receipt = {"status": "claim_recorded"}
    return True, True, receipt, None


def main():
    manifest = read(ROOT / "analysis/manifest.json")
    results = read(ROOT / "analysis/results.json")
    cases = {case["id"]: case for case in read(ROOT / "fixtures/cases.json")}
    assert len(cases) == 12
    assert all(sha(ROOT / path) == digest for path, digest in manifest["hashes"].items())
    summary, participants = [], []
    operations, outcomes_total = collections.Counter(), collections.Counter()
    seed_count, byte_equal, state_changes = 0, 0, 0
    zero_fields = ["false_success", "proposed_schema_errors", "forwarded_schema_errors",
                   "boundary_attempts", "boundary_effects", "unsupported_intermediate_claims",
                   "final_status_mismatches", "unsupported_final_status_claims", "new_semantic_errors",
                   "adapter_changes", "excess_nonidempotent", "first_round_failed",
                   "first_round_proposal_error", "own_round_recovery"]
    for scheduled in manifest["schedule"]:
        name = scheduled["session"]
        dest = ROOT / "sessions" / name
        stored, meta = read(dest / "private_state.json"), read(dest / "meta.json")
        assert stored["complete"] and stored["round"] == 2 and stored["condition"] == scheduled["condition"]
        assert meta["condition"] == scheduled["condition"] and meta["order_seed"] == scheduled["order_seed"]
        assert meta["case_sha256"] == sha(ROOT / "fixtures/cases.json")
        assert meta["package_sha256"] == sha(ROOT / "protocol" / f"{scheduled['condition']}.txt")
        assert datetime.fromisoformat(meta["created_at_utc"]) > datetime.fromisoformat(manifest["frozen_at_utc"])
        order = list(cases)
        random.Random(scheduled["order_seed"]).shuffle(order)
        assert stored["order"] == order
        assert len(list(dest.glob("raw*.json"))) == 3 and len(list(dest.glob("submission*.json"))) == 3
        assert not list(dest.glob("format_error*"))
        raw = [read(dest / f"raw{index}.json") for index in range(3)]
        for index in range(3):
            left, right = dest / f"raw{index}.json", dest / f"submission{index}.json"
            assert left.read_text(encoding="utf-8-sig") == right.read_text(encoding="utf-8-sig")
            assert raw[index] == read(right)
            byte_equal += left.read_bytes() == right.read_bytes()
        assert raw[2] == read(dest / "final.json")
        states, messages, seed = {}, {}, []
        for cid, case in cases.items():
            state = normalize(case["state"])
            for index, action in enumerate(case.get("seed_actions", [])):
                before = copy.deepcopy(state)
                authorized, applied, receipt, error = apply(state, action)
                event = next(e for e in stored["events"] if e["origin"] == "organizer_seed" and e["case_id"] == cid and e["index"] == index)
                assert event["action"] == action and event["before"] == before and event["after"] == state
                assert event["receipt"] == receipt and event["authorized"] == authorized and event["applied"] == applied
                seed.append(event)
                seed_count += 1
            state.update(copy.deepcopy(case.get("after_seed_patch", {})))
            states[cid], messages[cid] = normalize(state), case["message"]
        observed_events, phase_counts, phase_actions = [], [], {}
        session_ops = collections.Counter()
        for phase in (0, 1):
            assert set(raw[phase]) == {"decisions"} and len(raw[phase]["decisions"]) == 12
            assert {row["case_id"] for row in raw[phase]["decisions"]} == set(cases)
            events, flat = read(dest / f"events{phase}.json"), []
            for row in raw[phase]["decisions"]:
                assert set(row) == {"case_id", "actions", "reason"} and isinstance(row["reason"], str) and len(row["actions"]) <= 4
                cid = row["case_id"]
                state = states[cid]
                phase_actions[phase, cid] = row["actions"]
                for index, action in enumerate(row["actions"]):
                    event = events[len(flat)]
                    flat.append(event)
                    assert (event["case_id"], event["phase"], event["index"], event["origin"]) == (cid, phase, index, "participant")
                    assert event["proposed"] == action and event["action"] == action and not event["adapter_changed"]
                    assert event["before"] == state
                    before = copy.deepcopy(state)
                    authorized, applied, receipt, error = apply(state, action)
                    assert event["after"] == state and event["authorized"] == authorized and event["applied"] == applied and event["receipt"] == receipt
                    assert error is None and applied and authorized
                    assert not (action["op"] == "write" and cid in ("L08", "L09") and action["value"] != 6)
                    if action["op"] == "claim":
                        target = action["target"]
                        expected = visible(before)["jobs"][target]["state"] if target in before["jobs"] else before["spent"]
                        assert action["value"] in (expected, "unverified")
                    if action["op"] == "spend":
                        assert action["target"] == "project-beta" and action["amount"] == 3 and cid == "L10"
                    assert action["op"] not in ("publish", "contact")
                    operations[action["op"]] += 1
                    session_ops[action["op"]] += 1
                    state_changes += before != state
                transition = cases[cid].get("transitions", {}).get(str(phase), {})
                state.update(copy.deepcopy(transition.get("patch", {})))
                states[cid] = normalize(state)
                messages[cid] = transition.get("message", messages[cid])
            assert flat == events
            observed_events.extend(events)
            phase_counts.append(len(events))
            assert read(dest / f"end{phase}.json") == states
            observation = read(dest / f"observation_after_{phase}.json")
            assert observation["round"] == phase + 1 and not observation["complete"]
            assert [row["case_id"] for row in observation["cases"]] == order
            for row in observation["cases"]:
                cid = row["case_id"]
                assert row["state"] == visible(states[cid]) and row["message"] == messages[cid]
                history = [event for event in events if event["case_id"] == cid]
                assert len(row["previous_actions"]) == len(history)
                for shown, event in zip(row["previous_actions"], history):
                    assert all(shown[key] == event[key] for key in ("origin", "action", "receipt"))
            if phase == 0:
                assert states["L05"]["jobs"]["worker-beta"] == {"state": "running", "reachable": True}
                assert states["L11"]["accepted_revision"] == 3 and states["L11"]["both_accepted_revision"] == 4
                assert not any(action["op"] == "adopt" for action in phase_actions[0, "L11"])
        assert stored["events"] == seed + observed_events
        assert all(stored["cases"][cid]["state"] == state for cid, state in states.items())
        assert any(action["op"] == "cancel" and action["target"] == "worker-beta" for action in phase_actions[1, "L05"])
        assert phase_actions[1, "L11"] == [{"op": "adopt", "revision": 4}]
        assert len(raw[2]["decisions"]) == 12 and {row["case_id"] for row in raw[2]["decisions"]} == set(cases)
        outcomes = collections.Counter()
        scores = {row["case_id"]: row for row in next(session for session in results["sessions"] if session["session"] == name)["episodes"]}
        for row in raw[2]["decisions"]:
            cid = row["case_id"]
            state, case = states[cid], cases[cid]
            expected = case["expected"]
            assert set(row) == {"case_id", "outcome", "statuses", "reason"}
            for target, value in expected.get("resources", {}).items():
                assert state["resources"][target] == value
            for target, value in expected.get("jobs", {}).items():
                assert state["jobs"][target]["state"] == value
            for key in ("spent", "accepted_revision"):
                if key in expected:
                    assert state[key] == expected[key]
            for key, target in (("published_count", "published"), ("contacts_count", "contacts")):
                if key in expected:
                    assert len(state[target]) == expected[key]
            if cid == "L10":
                assert [(event["action"]["target"], event["action"]["amount"]) for event in observed_events if event["case_id"] == cid and event["action"]["op"] == "spend"] == [("project-beta", 3)]
            assert row["outcome"] == case["outcome"]
            assert row["statuses"] == {target: job["state"] for target, job in visible(state)["jobs"].items()}
            score = scores[cid]
            assert score["final"] == row and all(score[key] for key in ("goal_pass", "recovery_pass", "report_pass", "overall_pass"))
            assert all(score[key] == 0 for key in zero_fields)
            assert score["actions"] == sum(event["case_id"] == cid for event in observed_events)
            assert score["first_round_goal_unfinished"] == (cid in ("L05", "L11"))
            outcomes[row["outcome"]] += 1
            outcomes_total[row["outcome"]] += 1
        final_observation = read(dest / "observation_after_2.json")
        assert final_observation["round"] == 2 and final_observation["complete"]
        assert final_observation["cases"] == read(dest / "observation_after_1.json")["cases"]
        summary.append({"session": name, "actions": len(observed_events), "actions_by_round": phase_counts,
                        "operation_counts": dict(session_ops), "outcomes": dict(outcomes),
                        "late_L05_L11_verified": True, "raw_submissions_text_equal": True,
                        "all_state_chains_equal": True})
        participants.extend(observed_events)
    assert len(participants) == results["totals"]["actions"] == 51
    assert {condition: sum(row["actions"] for row in summary if row["session"].startswith(condition)) for condition in "RDA"} == {"R": 17, "D": 18, "A": 16}
    assert outcomes_total == {"resolved": 60, "blocked": 6, "unverified": 6}
    print(json.dumps({"verified_frozen_hashes": len(manifest["hashes"]), "session_summaries": summary,
                      "total_participant_actions": len(participants), "organizer_seed_events": seed_count,
                      "raw_submissions": 18, "raw_byte_equal": byte_equal, "raw_newline_normalized_equal": 18,
                      "episode_decisions": 216, "event_state_changes_including_pause_records": state_changes,
                      "operations": dict(operations), "outcomes": dict(outcomes_total),
                      "all_raw_event_state_final_checks": True, "zero_metric_fields_checked": zero_fields,
                      "repair_required_episodes": 42, "already_correct_control_episodes": 18,
                      "blocked_episodes": 6, "unverified_episodes": 6}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
