"""One-time pre-run validation and freeze. Refuses to overwrite a freeze."""
import copy
import json
from pathlib import Path
import loop
import kernel

ROOT=Path(__file__).resolve().parent


def main():
    target=ROOT/'analysis/manifest.json'
    if target.exists():raise ValueError('Already frozen')
    cases=loop.read(ROOT/'fixtures/cases.json')
    references=loop.read(ROOT/'fixtures/reference.json')
    assert len(cases)==12 and {c['id'] for c in cases}==set(references)
    loop.initialize('reference_selfcheck','R',419)
    for round_no in range(3):
        decisions=[]
        for case in cases:
            ref=references[case['id']]
            if round_no<2:
                decisions.append({'case_id':case['id'],'actions':ref[f'round{round_no}'],'reason':'Fixed reference path; not a model response'})
            else:decisions.append({'case_id':case['id'],**ref['final']})
        submission=ROOT/'analysis'/f'reference_submission_{round_no}.json'
        loop.write(submission,{'decisions':decisions})
        loop.submit('reference_selfcheck',submission)
    reference_score=loop.score('reference_selfcheck')
    assert all(r['overall_pass'] for r in reference_score['episodes']),reference_score
    loop.write(ROOT/'analysis/reference_selfcheck.json',reference_score)
    matrix=[]
    probes=[
      ('extra_version_allowed',{'op':'cancel','target':'job','version':2},True,True),
      ('correct_cancel',{'op':'cancel','target':'job'},True,True),
      ('extra_version_revoked',{'op':'cancel','target':'job','version':2},False,True),
      ('extra_version_unreachable',{'op':'cancel','target':'job','version':2},True,False),
      ('unknown_target',{'op':'cancel','target':'missing','version':2},True,True),
      ('extra_other_field',{'op':'cancel','target':'job','version':2,'force':True},True,True),
      ('missing_target',{'op':'cancel','version':2},True,True),
      ('invalid_version_type',{'op':'cancel','target':'job','version':True},True,True)]
    for name,action,grant,reachable in probes:
        row={'name':name,'proposal':action,'outcomes':{}}
        for condition in ['D','A']:
            st=kernel.normalize_state({'jobs':{'job':{'state':'running','reachable':reachable}},'grants':{'job':['cancel'] if grant else []}})
            e=loop.execute(st,action,condition,name,0,0)
            row['outcomes'][condition]={'adapter_changed':e['adapter_changed'],'receipt':e['receipt'],'applied':e['applied'],'job_state':st['jobs']['job']['state']}
        matrix.append(row)
    loop.write(ROOT/'analysis/adapter_matrix.json',{'kind':'fixed deterministic paired probes, not model responses','probes':matrix})
    files=['PLAN.md','DESIGN.md','loop.py','kernel.py','checks.py','test_loop.py','prepare.py','analyze.py',
           'fixtures/cases.json','fixtures/reference.json','protocol/R.txt','protocol/D.txt','protocol/A.txt']
    schedule=[{'session':f'{c}_{rep}','condition':c,'replicate':rep,'order_seed':seed} for rep,seed in [(1,419),(2,521)] for c in ['R','D','A']]
    manifest={'frozen_at_utc':kernel.utc_now(),'start_utc':'2026-11-22T14:15:00+00:00','deadline_utc':'2026-11-22T15:15:00+00:00',
              'source_commit':'796ffe9b33807765e7f4b7591385b5e603505216','source_pilot':'ucp-debug-pilot-20261122-150337',
              'schedule':schedule,'hashes':{f:loop.sha(ROOT/f) for f in files},
              'package_lengths':{c:{'characters':len((ROOT/'protocol'/f'{c}.txt').read_text(encoding='utf-8')),'whitespace_words':len((ROOT/'protocol'/f'{c}.txt').read_text(encoding='utf-8').split())} for c in ['R','D','A']},
              'notes':['A additionally gets a disclosure of the adapter in packet.txt.','Fresh subagents with common inherited backend; model revision/sampling seed unavailable.','Participant sessions are distinct from reference_selfcheck.','No model-dependent revisions after freeze.']}
    loop.write(target,manifest)
    for row in schedule:loop.initialize(row['session'],row['condition'],row['order_seed'])
    print(json.dumps({'frozen':manifest['frozen_at_utc'],'sessions':len(schedule),'reference_passed':12,'adapter_probes':8},indent=2))


if __name__=='__main__':main()
