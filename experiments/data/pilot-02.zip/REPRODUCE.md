# Reproduce the second UCP pilot's analysis

Use Python 3.11 or later. Only the standard library is required. Work on a copy of this completed directory; analysis writes derived results. The recorded sessions contain synthetic resources and simulation state. `private_state.json` is private only in the experimental participant-access procedure; it contains no real private account information.

```powershell
python -m unittest test_loop -v
python analyze.py
```

Expected: 8 unit tests pass; the analyzer finds all six sessions and confirms the frozen file hashes. Each condition R/D/A has 24/24 correct episodes and reports. Totals are 72 episodes and 51 actions, with no registered participant errors and zero adapter changes. There were no first-round participant failures, so a rate of own-error recovery is not estimable.

Inspect `analysis/results.json`, `analysis/adapter_matrix.json`, and `analysis/final_audit.md`. The adapter matrix has eight deterministic paired probes, not additional model responses. The reference session has twelve fixed reference episodes and is excluded from the model totals.

`PLAN.md`, `DESIGN.md`, and `analysis/manifest.json` document the pre-run design, deadlines, exact conditions and hashes. Sessions have three submissions: two action rounds and one report-only round. Observations after each submission show what was returned to the participant. Raw submissions are retained; Windows newline normalization means their bytes may differ from the submission-file representation while their parsed JSON agrees.

Do not run `prepare.py` in the completed directory. It documents the historical one-time preparation and refuses to replace the frozen manifest. `loop.py init` also refuses to replace an existing session. Reanalysis does not call a model or require an API key. New model generation is stochastic, and the exact inherited model revision was not exposed.

The copied `kernel.py` and `checks.py` retain their original auxiliary CLI functions for provenance. Use `loop.py` and `analyze.py` for this pilot. The dated files under `analysis/loop_before_*.py.txt` are preparation backups, not active code. The manifest identifies the frozen active files.
